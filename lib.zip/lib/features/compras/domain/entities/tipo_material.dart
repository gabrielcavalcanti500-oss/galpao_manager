enum TipoMaterial { peso, unidade }
