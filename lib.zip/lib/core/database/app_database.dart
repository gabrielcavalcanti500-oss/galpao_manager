import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();

  static final AppDatabase instance = AppDatabase._();

  Database? _database;

  Future<Database> get database async {
    if (_database != null) {
      return _database!;
    }

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final databasesPath = await getDatabasesPath();

    final path = join(databasesPath, 'galpao_manager.db');

    return openDatabase(
      path,
      version: 4,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE compras (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        data TEXT NOT NULL,
        total REAL NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE itens_compra (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        compra_id INTEGER NOT NULL,
        material_nome TEXT NOT NULL,
        tipo_material TEXT NOT NULL,
        quantidade REAL NOT NULL,
        preco_unitario REAL NOT NULL,
        subtotal REAL NOT NULL,
        FOREIGN KEY (compra_id)
          REFERENCES compras (id)
          ON DELETE CASCADE
      )
    ''');

    await _criarTabelaGastos(db);
    await _criarTabelasVendas(db);
    await _criarTabelaRetiradas(db);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await _criarTabelaGastos(db);
    }

    if (oldVersion < 3) {
      await _criarTabelasVendas(db);
    }

    if (oldVersion < 4) {
      await _criarTabelaRetiradas(db);
    }
  }

  Future<void> _criarTabelaGastos(Database db) async {
    await db.execute('''
      CREATE TABLE gastos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        descricao TEXT NOT NULL,
        valor REAL NOT NULL,
        data TEXT NOT NULL,
        observacao TEXT
      )
    ''');
  }

  Future<void> _criarTabelasVendas(Database db) async {
    await db.execute('''
      CREATE TABLE vendas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        data TEXT NOT NULL,
        total REAL NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE itens_venda (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        venda_id INTEGER NOT NULL,
        material_nome TEXT NOT NULL,
        tipo_material TEXT NOT NULL,
        quantidade REAL NOT NULL,
        preco_unitario REAL NOT NULL,
        subtotal REAL NOT NULL,
        FOREIGN KEY (venda_id)
          REFERENCES vendas (id)
          ON DELETE CASCADE
      )
    ''');
  }

  Future<void> _criarTabelaRetiradas(Database db) async {
    await db.execute('''
      CREATE TABLE retiradas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        material_nome TEXT NOT NULL,
        tipo_material TEXT NOT NULL,
        quantidade REAL NOT NULL,
        data TEXT NOT NULL
      )
    ''');
  }
}
